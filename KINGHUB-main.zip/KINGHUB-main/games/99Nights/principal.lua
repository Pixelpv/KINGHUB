-- Script principal do jogo 99Nights

local function iniciarJogo()
    print("[99Nights] Jogo iniciado!")
end

iniciarJogo()