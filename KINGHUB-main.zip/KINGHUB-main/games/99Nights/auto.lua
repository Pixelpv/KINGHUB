-- Funções automáticas para o jogo

local Auto = {}

function Auto.farmar()
    print("[99Nights] Farm automático ativado!")
end

return Auto