-- Scripts de efeitos visuais

local Visuais = {}

function Visuais.mudarCor(cor)
    print("[99Nights] Mudando cor dos visuais para:", cor)
end

return Visuais