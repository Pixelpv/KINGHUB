-- Arquivo de configurações do jogo

local Configs = {
    dificuldade = "normal",
    maxPlayers = 4
}

return Configs
