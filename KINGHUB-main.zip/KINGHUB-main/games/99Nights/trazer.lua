-- Função de trazer jogadores ou objetos

local function trazerJogador(nome)
    print("[99Nights] Trazendo jogador:", nome)
end

return trazerJogador
