-- Carrega o jogo selecionado

local Loader = {}

function Loader.loadSelectedGame()
    print("[Loader] Nenhum jogo selecionado para carregar.")
    -- Aqui você poderia adicionar lógica para escolher e carregar um jogo
end

return Loader