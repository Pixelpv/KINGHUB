-- Proteções gerais

local Security = {}

function Security.startProtections()
    print("[Security] Proteções básicas ativadas.")
    -- Adicione suas rotinas de proteção aqui
end

return Security